# view_db.py
import sqlite3

conn = sqlite3.connect('database.db')
c = conn.cursor()
c.execute("SELECT * FROM users")
users = c.fetchall()
conn.close()

for user in users:
    print(user)